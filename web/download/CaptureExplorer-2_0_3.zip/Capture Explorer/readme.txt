﻿截圖整理工具：版本 2.0.3
(2018/09/28)

討論區：
https://forum.gamer.com.tw/C.php?bsn=60076&snA=4337057

作者：
hbl917070(深海異音)

作者小屋：
https://home.gamer.com.tw/homeindex.php?owner=hbl917070

使用需求：
win7 以上、net 4.6.1 (含)以上
補充：
net 4.7.1 載點 https://www.microsoft.com/zh-TW/download/details.aspx?id=56116

2.0.3
進入選取截圖時，支援更多快速鍵
新增正方形選取
新增單層儲存路徑


2.0.2
新增目前視窗截圖
新增自定儲存路徑
新增放大鏡功能

2.0.1
新增全螢幕截圖
修正截圖會重複啟用的BUG


2.0.0
新增資料夾分頁管理
新增編輯模式
新增縮小至工作列圖示
新增截圖坐標
新增吸取顏色
修改為AERO毛玻璃界面
修正截圖範圍有1px誤差的BUG
修正關閉程式後出現錯誤訊息的BUG



